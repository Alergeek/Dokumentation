/** Automatically generated file. DO NOT MODIFY */
package allergeeks.edible.vuzix_app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}